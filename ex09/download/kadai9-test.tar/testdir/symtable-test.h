// symtable-test.cc で定義されている関数のプロトタイプ宣言

void printAllGlobalSymbols();
void printAllSymbols();
void printSymbol(SymbolEntry *symbol);
