// calc{3,4}.y と calc34-scanner.cc で用いる定数の定義

// 演算子トークンの属性を表す定数の定義
enum CConst { Cadd, Csubtract, Cmultiply, Cdivide, Cmodulo };
